import numpy as np 
import imageio.v2 as imageio
from tqdm import tqdm 

from utils import *

"""
Computes the image mean and standard deviation of the training set

"""

n_channels = 3

for fold in range(4):
    patient_subset_txt = '4_fold_splits' + '/' + str(fold+1) + '_train.txt'
    with open(patient_subset_txt, 'r') as f:
        img_list = f.read().splitlines()
    img_list = sorted_alphanumeric(img_list)

    n = len(img_list)
    print(n)

    sum_img = np.zeros((n, n_channels))
    stddev_list = np.zeros((n, n_channels))

    for i in tqdm(range(n)):
        img = imageio.imread(img_list[i])
        # img = np.moveaxis(img, 0, -1)

        pixels_per_img = img.shape[0]*img.shape[1]

        sum_img[i,:] = np.sum(img,(0,1)) / pixels_per_img
        stddev_list[i,:] = np.std(img,(0,1))

    mean = np.mean(sum_img, 0)
    stddev = np.mean(stddev_list, 0)

    print('Fold %d' %(fold+1))
    print('Means')
    print(list(np.around(mean,5)))
    print('Stds')
    print(list(np.around(stddev,5)))



"""

7758
100%|████████████████████████████████████████████████████████████████████████████████████| 7758/7758 [00:50<00:00, 154.68it/s]
Fold 1
Means
[151.55743, 138.90703, 179.98677]
Stds
[50.95315, 43.17401, 35.02942]
8137
100%|████████████████████████████████████████████████████████████████████████████████████| 8137/8137 [00:52<00:00, 155.75it/s]
Fold 2
Means
[152.19036, 139.6147, 182.15098]
Stds
[50.45269, 41.40635, 33.50534]
9458
100%|████████████████████████████████████████████████████████████████████████████████████| 9458/9458 [00:57<00:00, 163.66it/s]
Fold 3
Means
[153.56228, 139.52514, 181.90806]
Stds
[50.62873, 42.4374, 34.48482]
7982
100%|████████████████████████████████████████████████████████████████████████████████████| 7982/7982 [01:01<00:00, 130.01it/s]
Fold 4
Means
[149.30544, 137.27176, 177.80201]
Stds
[52.69684, 45.10709, 36.79179]


"""