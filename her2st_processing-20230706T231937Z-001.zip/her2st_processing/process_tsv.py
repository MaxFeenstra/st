import numpy as np 
import glob
import pandas as pd
from utils import *

fp_histogene = '../her_hvg_cut_1000.npy'
gene_list = list(np.load(fp_histogene, allow_pickle=True))

fp_dir = '../her2st/data/ST-cnts'

fp_out = 'processed_expr.csv'

fp_tsv = glob.glob(fp_dir+'/**/*.tsv.gz', recursive=True)
fp_tsv = [x.replace('\\','/') for x in fp_tsv]

for i, tsv in enumerate(fp_tsv):
    df = pd.read_csv(tsv, compression='gzip', header=0, sep='\t', quotechar='"', index_col=0)
    assert(len(list(set(gene_list) & set(list(df.columns)))) == len(gene_list))

    df_slice = df[gene_list].copy()
    sample_id = os.path.basename(tsv).split('.')[-3]
    df_slice.index = f"{sample_id}_" + df_slice.index

    if i == 0:
        df_new = df_slice.copy()
    else:
        df_new = pd.concat([df_new, df_slice], ignore_index=False)
    
df_new.to_csv(fp_out, index=True)