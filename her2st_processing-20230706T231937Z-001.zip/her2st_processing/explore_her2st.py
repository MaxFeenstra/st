import numpy as np 
import imageio.v2 as imageio
import pandas as pd 
import matplotlib.pyplot as plt 

fp_img = "../her2st/data/ST-imgs/A/A1/9769_C1_HE_small.jpg"
fp_exp = "../her2st/data/ST-spotfiles/A1_selection.tsv"

# fp_img = "../her2st/data/ST-imgs/C/C3/5714_HE_BT_D1.jpg"
# fp_exp = "../her2st/data/ST-spotfiles/C3_selection.tsv"

img = imageio.imread(fp_img)
print(img.shape)

df = pd.read_csv(fp_exp, sep='\t')
df = df.sort_values('pixel_x')

print(df.head(n=10))

# print(df['pixel_x'].max())
# print(df['pixel_x'].min())
# print(df['pixel_y'].max())
# print(df['pixel_y'].min())

plt.figure()
plt.imshow(img)
for p,q in zip(df['pixel_x'], df['pixel_y']):
    x_cord = p # try this change (p and q are already the coordinates)
    y_cord = q
    plt.scatter([x_cord], [y_cord])
plt.show()