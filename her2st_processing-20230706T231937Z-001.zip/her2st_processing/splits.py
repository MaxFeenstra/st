import numpy as np 
import glob 
import natsort
import os 
import random 

def make_dir(dir_path):
    """
    Make directory if doesn't exist
    """
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

# 4-fold cross-valiation, split on patient letters 
n_sets = 4
n_val_pat = 1
# Fraction of patients to go into training set (will be floored to int)
train_frac = 1 - 1/n_sets

fp_imgs = glob.glob('patches/**/*.jpg', recursive=True)
fp_imgs = [x.replace('\\','/') for x in fp_imgs]
sample_ids = [x.split('/')[-2] for x in fp_imgs]

patients_list = list(set([x[0] for x in sample_ids]))
patients_list = natsort.natsorted(patients_list)
# print(patients_list)

n_patients = len(patients_list)
# print('Number of total patients: %d' %n_patients)

# For saving the lists of patients in training and testing sets
OUTPUT_DIR = '%d_fold_splits/' %n_sets
make_dir(OUTPUT_DIR)

# Number of training and testing patients
n_train = np.floor(n_patients*train_frac)
n_test = int(n_patients - n_train)
print('n patients train: %d, n patients test: %d' %(n_train, n_test))

n_test_per_fold = np.ones(n_sets)*n_test
n_train_per_fold = np.zeros(n_sets)
n_train_per_fold = [n_patients - x for x in n_test_per_fold]
print(n_test_per_fold)
print(n_train_per_fold)

# # Number of patients in total not a whole multiple of test patients
# shortage = n_test*n_sets - n_patients
# if shortage > 0:
#     for i in range(shortage):
#         n_test_per_fold[-(i+1)] -= 1
# n_train_per_fold = [n_patients - x for x in n_test_per_fold]

random.shuffle(patients_list)

for fold in range(n_sets):
    n_test_fold = int(n_test_per_fold[fold])
    n_train_fold = int(n_train_per_fold[fold])

    start_n = int(np.sum(n_test_per_fold[:fold]))
    # print(start_n, fold*n_test_fold)
    fold_test = patients_list[start_n : start_n+n_test_fold]
    # fold_test = patients_list[fold*n_test_fold : fold*n_test_fold+n_test_fold]
    # assert(len(fold_test) == n_test_fold), print(len(fold_test), n_test_fold)

    # fold_train = list(set(patients_list) - set(fold_test))
    fold_train = [x for x in patients_list if x not in fold_test]
    # assert(len(fold_train) == n_train_fold), print(len(fold_train), n_train_fold)

    assert(len(list(set(fold_test).intersection(fold_train))) == 0)

    fold_val = random.choice(fold_train)

    fold_train.remove(fold_val)

    fold_val = [fold_val]

    # Get filenames for the patients
    files_train = [x for x in fp_imgs if any(('/' + substring) in x for substring in fold_train)]
    files_test = [x for x in fp_imgs if any(('/' + substring) in x for substring in fold_test)]
    files_val = [x for x in fp_imgs if any(('/' + substring) in x for substring in fold_val)]

    print(fold, len(fold_train), len(fold_test), len(fold_val))
    print(fold, len(files_train), len(files_test), len(files_val))
    
    train_txt_fp = OUTPUT_DIR + str(fold+1) + '_' + 'train' + '.txt'
    test_txt_fp = OUTPUT_DIR + str(fold+1) + '_' + 'test' + '.txt'
    val_txt_fp = OUTPUT_DIR + str(fold+1) + '_' + 'val' + '.txt'

    train_txt_pid = OUTPUT_DIR + str(fold+1) + '_' + 'train_pid' + '.txt'
    test_txt_pid = OUTPUT_DIR + str(fold+1) + '_' + 'test_pid' + '.txt'
    val_txt_pid = OUTPUT_DIR + str(fold+1) + '_' + 'val_pid' + '.txt'

    with open(train_txt_fp, 'w') as fp:
        fp.write('\n'.join('%s' % x for x in files_train))
    with open(test_txt_fp, 'w') as fp:
        fp.write('\n'.join('%s' % x for x in files_test))
    with open(val_txt_fp, 'w') as fp:
        fp.write('\n'.join('%s' % x for x in files_val))

    with open(train_txt_pid, 'w') as fp:
        fp.write('\n'.join('%s' % x for x in fold_train))
    with open(test_txt_pid, 'w') as fp:
        fp.write('\n'.join('%s' % x for x in fold_test))
    with open(val_txt_pid, 'w') as fp:
        fp.write('\n'.join('%s' % x for x in fold_val))