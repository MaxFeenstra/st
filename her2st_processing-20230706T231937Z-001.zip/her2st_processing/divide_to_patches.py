import numpy as np 
import imageio.v2 as imageio
import pandas as pd 
import matplotlib.pyplot as plt 
import matplotlib.patches as patches
import os
import re

def sorted_alphanumeric(data):
    """
    Alphanumerically sort a list
    """
    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(data, key=alphanum_key)

def get_files_list(path, ext_array=['.jpg']):
    """
    Get all files in a directory with a specific extension
    """
    files_list = list()
    dirs_list = list()

    for root, dirs, files in os.walk(path, topdown=True):
        for file in files:
            if any(x in file for x in ext_array):
                files_list.append(os.path.join(root, file))
                folder = os.path.dirname(os.path.join(root, file))
                if folder not in dirs_list:
                    dirs_list.append(folder)

    return files_list, dirs_list

def make_dir(dir_path):
    """
    Make directory if doesn't exist
    """
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

################################################################################

fp_img = "../her2st/data/ST-imgs"
fp_exp = "../her2st/data/ST-spotfiles"
spotfiles_fp_str = "_selection.tsv"

dir_output = "patches"
make_dir(dir_output)

################################################################################

fp_list_img, _ = get_files_list(fp_img)
fp_list_img = [x.replace('\\','/') for x in fp_list_img]
fp_list_img = sorted_alphanumeric(fp_list_img)

pat_list = [x.split('/')[-2] for x in fp_list_img]

# fp_list_exp = [(fp_exp + '/' + x + spotfiles_fp_str) for x in pat_list]

################################################################################

for fp_img in fp_list_img:
    pat = fp_img.split('/')[-2]
    print(pat)
    dir_pat = dir_output + '/' + pat 
    make_dir(dir_pat)

    df = pd.read_csv(fp_exp + '/' + pat + spotfiles_fp_str, sep='\t')
    df = df.round().astype(int)

    img = imageio.imread(fp_img)

    # Calculate the average pixel_x for all cols x 
    avg_x_means = df.groupby(['x']).mean().round().astype(int)
    n_x = avg_x_means.shape[0]
    avg_x_means_diff = avg_x_means.diff().iloc[1:,:]['pixel_x']

    # Average distance between average col locations
    avg_x_means_diff_mean = avg_x_means_diff.mean().round().astype(int)
    # Starting col point location 
    start_x = avg_x_means.iloc[0,:]['pixel_x']
    end_x = avg_x_means.iloc[-1,:]['pixel_x']

    # Calculate the average pixel_y for all rows y 
    avg_y_means = df.groupby(['y']).mean().round().astype(int)
    n_y = avg_y_means.shape[0]
    avg_y_means_diff = avg_y_means.diff().iloc[1:,:]['pixel_y']

    # Average distance between average row locations
    avg_y_means_diff_mean = avg_y_means_diff.mean().round().astype(int)
    # Starting row point location 
    start_y = avg_y_means.iloc[0,:]['pixel_y']
    end_y = avg_y_means.iloc[-1,:]['pixel_y']

    print(start_x, n_x, avg_x_means_diff_mean, end_x)
    print(end_y, n_y, avg_y_means_diff_mean, end_y)

    # Make even if odd 
    if avg_x_means_diff_mean % 2 != 0:
        avg_x_means_diff_mean += 1
    if avg_y_means_diff_mean % 2 != 0:
        avg_y_means_diff_mean += 1

    delta_x = int(avg_x_means_diff_mean/2)
    delta_y = int(avg_y_means_diff_mean/2)

    # NEW CENTRES
    new_xc = [start_x+i*avg_x_means_diff_mean for i in range(n_x)]
    new_yc = [start_y+i*avg_y_means_diff_mean for i in range(n_y)]

    # Take crops and save
    # for xc, yc in zip(new_xc, new_yc):
    for xc in new_xc:

        # Closest x and y spot indices
        closest_x = df.iloc[(df['pixel_x']-xc).abs().argsort()[0]]['x']

        df_closest_x = df.loc[df['x'] == closest_x]

        for curr_ys in df_closest_x['pixel_y']:
            # Find closest to new coordinates
            yc = min(new_yc, key=lambda x:abs(x-curr_ys))

            curr_xs = df_closest_x.loc[df_closest_x['pixel_y'] == curr_ys].iloc[0]['pixel_x']

            closest_y = df_closest_x.loc[df_closest_x['pixel_y'] == curr_ys].iloc[0]['y']

            # Format example 3x12 
            output_fp = dir_pat + '/' + str(closest_x) + 'x' + str(closest_y) + '.jpg'
            print(output_fp)

            patch = img[yc-delta_y:yc+delta_y, xc-delta_x:xc+delta_x]
            imageio.imwrite(output_fp, patch)


        #     # VISUALISE

        #     if xc == 5433:
        #         # Create figure and axes
        #         fig, ax = plt.subplots()

        #         # Display the image
        #         ax.imshow(img)

        #         # Create a Rectangle patch
        #         rect = patches.Rectangle((xc-delta_x, yc-delta_y), avg_x_means_diff_mean, avg_y_means_diff_mean, linewidth=1, edgecolor='r', facecolor='none')

        #         x_cord = curr_xs # try this change (p and q are already the coordinates)
        #         y_cord = curr_ys
        #         ax.scatter([x_cord], [y_cord])

        #         # Add the patch to the Axes
        #         ax.add_patch(rect)

        # if xc == 5433:
        #     plt.show()
