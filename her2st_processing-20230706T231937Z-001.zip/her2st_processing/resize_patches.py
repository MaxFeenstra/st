import imageio.v2 as imageio 
from skimage.transform import resize
import numpy as np 
import glob
from tqdm import tqdm
import os
from utils import *

dir_output = 'patches_resized/'
make_dir(dir_output)

dims = [224, 224]
fp_imgs = glob.glob('patches/**/*.jpg', recursive=True)
fp_imgs = [x.replace('\\','/') for x in fp_imgs]
print(len(fp_imgs))

for fp in tqdm(fp_imgs):
    img = imageio.imread(fp)
    img = resize(img, order=1, output_shape=(dims[0], dims[1]), preserve_range=True)

    fp_output = fp.replace('patches/', dir_output)
    fp_dir = fp_output.replace(fp_output.split('/')[-1],'')
    make_dir(fp_dir)

    imageio.imwrite(fp_output, img.astype(np.uint8))
