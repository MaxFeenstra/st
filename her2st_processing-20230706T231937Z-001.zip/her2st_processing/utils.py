import numpy as np
import os
from fnmatch import fnmatch
import re
import matplotlib.pyplot as plt
import math

"""
Alphanumerically sort a list
"""
def sorted_alphanumeric(data):
    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(data, key=alphanum_key)

"""
Make directory if doesn't exist
"""
def make_dir(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

"""
Delete file if exists
"""
def delete_file(path):
    if os.path.exists(path):
        os.remove(path)

"""
Get all files in a directory with a specific extension
"""
def get_files_list(path, ext_array=['.dcm']):
    files_list = list()
    dirs_list = list()

    for root, dirs, files in os.walk(path, topdown=True):
        for file in files:
            if any(x in file for x in ext_array):
                files_list.append(os.path.join(root, file))
                folder = os.path.dirname(os.path.join(root, file))
                if folder not in dirs_list:
                    dirs_list.append(folder)
        # for directory in dirs:
        #     dirs_list.append(os.path.join(root, directory))

    return files_list, dirs_list